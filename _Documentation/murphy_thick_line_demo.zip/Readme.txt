Murphy's Modification to Bresenham's Algorithm for drawing Thick Lines.
----------------------------------------------------------------------


This ZIP file contains a demo program which illustrates the thick 
line drawing algorithm.

Place all the files in any convenient directory and run TLINEALG.EXE.

This is a 16-bit Delphi 1 compilation of the source code which is 
also included in the package. You can inspect the THCKLINE.PAS file
to see the algorithm.

Warning: The code is not well tested, so please save all data in  other
programs before running.

Any questions, suggestions etc. to 
Alan Murphy
murphy@enterprise.net

 